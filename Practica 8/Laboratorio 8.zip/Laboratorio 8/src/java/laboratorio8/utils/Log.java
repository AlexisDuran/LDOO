/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratorio8.utils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author user
 */
public class Log {

    final private String fileName;
    private static Log instance = null;

    private Log(String fileName) {
        this.fileName = fileName;
    }

    public static Log getInstance(String fileName) {
        if (instance == null) {
            instance = new Log(fileName);
        }
        return instance;
    }

    public void write(String message) {
        try {
            try (BufferedWriter br = new BufferedWriter(new FileWriter(this.fileName, true))) {
                DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Calendar cal = Calendar.getInstance();

                //Create the name of the file from the path and current time
                String data = "\n" + dateFormat.format(cal.getTime()) + ": " + message;
                br.write(data);
            }
        } catch (Exception e) {
        }
    }
}
//se aplica en el if de comentarios e insertar para que se genere un log de errores
//catch(Exception e){}
//   Log log = Log.getInstance("C:\\ruta\\log.txt");   **esto va en la instancia del metodo
//  log.write(e.getMessage);                       **esto va en el catch
//
