/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Laboratorio5.models;

/**
 *
 * @author 4r#4k
 */
public class Authentication {
    public static boolean authenticate(String username, String password) {
    String userDataBase = "userr";
    String passwordDataBase = "pss";
    if(username.equals(userDataBase) && password.equals(passwordDataBase)) {
        return true;
    }
    else {
        return false;
    }    
    }
}
