package modelo;

import java.sql.Connection;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Alexis Duran m.1479832
 */
public class ComentariosDAO {

    Connection conexion;

    private void abrirConexion() throws SQLException {
        String dbURL = "jdbc:derby://localhost:1527/Comentarios";
        //mala practica
        String username = "fcfm";
        String password = "lsti01";
        conexion = DriverManager.getConnection(dbURL, username, password);
    }

    private void cerrarConexion() throws SQLException {
        conexion.close();
    }

    public void insertar(ComentariosPOJO pojo) {
        try {
            abrirConexion();

            String sql = "insert into COMENTARIOS values('" + pojo.getNombre() + "','" + pojo.getComentario() + "')";
            Statement stmt = conexion.createStatement();
            stmt.executeUpdate(sql);
            cerrarConexion();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
        }
    }

    public List buscar(ComentariosPOJO pojo) throws SQLException {
        ResultSet rs;
        List beans = new ArrayList();
        try {
            abrirConexion();
            String sql = "select * from COMENTARIO where NOMBRE = '" + pojo.getNombre() + "' and COMENTARIO like '%" + pojo.getComentario() + "%'";
            Statement stmt = conexion.createStatement();
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                String name = rs.getString("NOMBRE");
                String coments = rs.getString("COMENTARIO");
                ComentariosPOJO piojo = new ComentariosPOJO(name, coments);
                beans.add(piojo);
                rs.close();
            }
        } catch (SQLException esql) {

        } finally {
        }
        cerrarConexion();
        return beans;
    }
}
