/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package week5.models;

/**
 *
 * @author 4r#4k
 */
public class User {
    private String username;
    private String password;
    
    public User(String user, String pass){
       username = user;
       password = pass;
    }
    
    public String getUsername(){
        return username;
    }
    public String getPassword(){
        return password;
    }
}
