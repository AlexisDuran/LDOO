package modelo;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 //Un POJO (Plain Old Java Object) es un objeto que sirve para representar un registro de una tabla de base de datos.

/**
 * m.1479832
 * @author Alexis Duran
 */
public class ComentariosPOJO {

    private String nombre;
    private String comentario;

    public ComentariosPOJO(String nombre, String comentario) {
        setNombre(nombre);
        setComentario(comentario);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

}
